package com.justdeax.opentetris
import android.annotation.SuppressLint
import android.os.Bundle
import android.view.MotionEvent
import android.widget.Button
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlin.math.abs

class MainActivity : AppCompatActivity() {
    private val rows = 20
    private val cols = 10
    private val tetrisGame: TetrisGameViewModel by viewModels {
        TetrisGameFactory(rows, cols)
    }
    private lateinit var boardView: BoardView
    private lateinit var previous: TextView
    private lateinit var score: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        setPadding()

        boardView = findViewById(R.id.boardView)
        previous = findViewById(R.id.previous)
        score = findViewById(R.id.score)
        setControls()
        val startStopButton: Button = findViewById(R.id.stop_start)
        val pauseButton: Button = findViewById(R.id.pause)
        val resumeButton: Button = findViewById(R.id.resume)
        startStopButton.setOnClickListener { tetrisGame.startGame() }
        pauseButton.setOnClickListener { tetrisGame.stopGame() }
        resumeButton.setOnClickListener { tetrisGame.resumeGame() }

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                tetrisGame.board.collectLatest { board ->
                    boardView.updateBoard(board)
                    score.text = tetrisGame.score.toString()
                }
            }
        }

        tetrisGame.startGame()
    }

    private fun setControls() {
        var lastTouchX = 0f
        var lastTouchY = 0f
        @SuppressLint("ClickableViewAccessibility")
        boardView.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    lastTouchX = event.x
                    lastTouchY = event.y
                }
                MotionEvent.ACTION_MOVE -> {
                    val diffX = event.x - lastTouchX
                    val diffY = event.y - lastTouchY
                    val thresholdX = boardView.width / 5 * 0.4f
                    val thresholdY = boardView.height / 10 * 0.4f

                    if (abs(diffX) > thresholdX && abs(diffY) < thresholdY) {
                        if (diffX > 0) tetrisGame.moveRight()
                        else tetrisGame.moveLeft()
                        lastTouchX = event.x
                    }

                    if (diffY > thresholdY) {
                        tetrisGame.dropPiece()
                        lastTouchY = event.y
                    }

                    boardView.invalidate()
                }
                MotionEvent.ACTION_UP -> {
                    val diffX = abs(event.x - lastTouchX)
                    val diffY = abs(event.y - lastTouchY)
                    if (diffX < 5 && diffY < 5) tetrisGame.rotatePiece()

                    lastTouchX = -1f
                    lastTouchY = -1f
                }
            }
            true
        }
    }

    private fun setPadding() {
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }
}